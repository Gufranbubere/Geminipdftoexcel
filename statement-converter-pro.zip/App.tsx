
import React, { useState, useCallback } from 'react';
import { Transaction } from './types';
import { extractTextFromPdf } from './services/pdfParsingService';
import { extractTransactionsWithGemini } from './services/geminiService';
import { downloadCsv } from './utils/csvHelper';
import FileUpload from './components/FileUpload';
import TransactionTable from './components/TransactionTable';
import LoadingSpinner from './components/LoadingSpinner';
import { DownloadIcon } from './components/icons/DownloadIcon';
import { ClearIcon } from './components/icons/ClearIcon';

const App: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string>('');

  const handleFileChange = (selectedFile: File | null) => {
    if (selectedFile) {
      setFile(selectedFile);
      setFileName(selectedFile.name);
      setTransactions([]);
      setError(null);
    }
  };

  const processPdf = useCallback(async () => {
    if (!file) {
      setError('Please select a PDF file first.');
      return;
    }

    setIsLoading(true);
    setError(null);
    setTransactions([]);

    try {
      const pdfText = await extractTextFromPdf(file);
      if (!pdfText || !pdfText.trim()) {
        setError('Could not extract text from the PDF. The PDF might be image-based and OCR failed, or it might be empty, encrypted, corrupted, or have an unsupported format. Please try a different PDF.');
        setIsLoading(false);
        return;
      }

      const extractedData = await extractTransactionsWithGemini(pdfText);
      setTransactions(extractedData);
      if (extractedData.length === 0) {
         setError(
          'No transactions found or AI could not parse the statement structure. ' +
          'Try a different statement or check if the PDF content is clear. ' +
          'For very long PDFs processed in parts, some transactions might be missed if they span processed sections unclearly.'
        );
      }
    } catch (err) {
      console.error('Processing error:', err);
      let errorMessage = 'An unknown error occurred during processing.';
      if (err instanceof Error) {
        if (err.message.includes("API_KEY") || err.message.includes("API key") || err.message.toLowerCase().includes("api key")) {
            errorMessage = "Error: API Key is not configured or invalid. Please ensure the API_KEY environment variable is set correctly for the application to function.";
        } else {
            errorMessage = err.message;
        }
      }
      setError(errorMessage);
    } finally {
      setIsLoading(false);
    }
  }, [file]);

  const handleDownloadCsv = () => {
    if (transactions.length === 0) {
      setError('No transactions to download.');
      return;
    }
    const csvFileName = fileName ? `${fileName.split('.').slice(0, -1).join('.')}_transactions.csv` : 'transactions.csv';
    downloadCsv(transactions, csvFileName);
  };

  const handleClear = () => {
    setFile(null);
    setFileName('');
    setTransactions([]);
    setError(null);
    setIsLoading(false);
    const fileInput = document.getElementById('pdf-upload') as HTMLInputElement;
    if (fileInput) {
        fileInput.value = '';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-700 text-slate-100 flex flex-col items-center p-4 sm:p-8">
      <header className="w-full max-w-4xl mb-8 text-center">
        <h1 className="text-4xl sm:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-blue-500">
          Statement Converter Pro
        </h1>
        <p className="mt-2 text-slate-300 text-sm sm:text-base">
          Upload your PDF bank or credit card statement to extract transactions into a CSV format.
        </p>
      </header>

      <main className="w-full max-w-4xl bg-slate-800 shadow-2xl rounded-xl p-6 sm:p-8">
        <FileUpload onFileSelect={handleFileChange} currentFileName={fileName} />

        {error && (
          <div className="mt-4 p-3 bg-red-500/20 text-red-300 border border-red-500 rounded-md text-sm break-words">
            <strong>Error:</strong> {error}
          </div>
        )}

        <div className="mt-6 flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
          <button
            onClick={processPdf}
            disabled={!file || isLoading}
            className="w-full sm:w-auto flex-1 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-600 disabled:cursor-not-allowed text-white font-semibold py-3 px-6 rounded-lg shadow-md transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-opacity-75"
          >
            {isLoading ? <LoadingSpinner /> : 'Extract Transactions'}
          </button>
          <button
            onClick={handleClear}
            className="w-full sm:w-auto bg-slate-600 hover:bg-slate-500 text-slate-100 font-semibold py-3 px-6 rounded-lg shadow-md transition-colors duration-150 flex items-center justify-center focus:outline-none focus:ring-2 focus:ring-slate-400 focus:ring-opacity-75"
            title="Clear selection and results"
          >
            <ClearIcon className="w-5 h-5 mr-2" /> Clear
          </button>
        </div>
        
        {transactions.length > 0 && !isLoading && (
          <div className="mt-8">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-2xl font-semibold text-slate-200">Extracted Transactions</h2>
              <button
                onClick={handleDownloadCsv}
                className="bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-4 rounded-lg shadow-md transition-colors duration-150 flex items-center focus:outline-none focus:ring-2 focus:ring-green-400 focus:ring-opacity-75"
                title="Download as CSV"
              >
                <DownloadIcon className="w-5 h-5 mr-2" /> Download CSV
              </button>
            </div>
            <TransactionTable transactions={transactions} />
          </div>
        )}
      </main>

      <footer className="w-full max-w-4xl mt-12 text-center text-slate-400 text-xs">
        <p>&copy; {new Date().getFullYear()} Statement Converter Pro. Powered by Gemini AI.</p>
        <p className="mt-1">
          For best results, use clear, text-based PDF statements. Image-based PDFs or very long PDFs (processed in parts) may take longer or yield partial results.
        </p>
         <p className="mt-1 text-red-400 text-xs">Note: An API Key for Gemini must be configured in the environment as process.env.API_KEY for this application to function.</p>
      </footer>
    </div>
  );
};

export default App;
