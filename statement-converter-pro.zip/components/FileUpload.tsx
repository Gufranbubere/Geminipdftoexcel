
import React, { useRef } from 'react';
import { UploadIcon } from './icons/UploadIcon';

interface FileUploadProps {
  onFileSelect: (file: File | null) => void;
  currentFileName: string | null;
}

const FileUpload: React.FC<FileUploadProps> = ({ onFileSelect, currentFileName }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files ? event.target.files[0] : null;
    if (file && file.type === "application/pdf") {
      onFileSelect(file);
    } else {
      onFileSelect(null);
      // Optionally, display an error message if not a PDF
      if (file) alert("Please select a PDF file.");
    }
  };

  const handleDragOver = (event: React.DragEvent<HTMLLabelElement>) => {
    event.preventDefault();
    event.stopPropagation();
    event.currentTarget.classList.add('border-blue-500', 'bg-slate-700');
  };

  const handleDragLeave = (event: React.DragEvent<HTMLLabelElement>) => {
    event.preventDefault();
    event.stopPropagation();
    event.currentTarget.classList.remove('border-blue-500', 'bg-slate-700');
  };

  const handleDrop = (event: React.DragEvent<HTMLLabelElement>) => {
    event.preventDefault();
    event.stopPropagation();
    event.currentTarget.classList.remove('border-blue-500', 'bg-slate-700');
    const file = event.dataTransfer.files ? event.dataTransfer.files[0] : null;
    if (file && file.type === "application/pdf") {
      onFileSelect(file);
      if (fileInputRef.current) {
        fileInputRef.current.files = event.dataTransfer.files; // Synchronize with input
      }
    } else {
      onFileSelect(null);
      if (file) alert("Please select a PDF file.");
    }
  };

  return (
    <div className="mb-6">
      <label
        htmlFor="pdf-upload"
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className="flex flex-col items-center justify-center w-full h-48 sm:h-56 border-2 border-slate-500 border-dashed rounded-lg cursor-pointer bg-slate-700/50 hover:bg-slate-700 transition-colors duration-150"
      >
        <div className="flex flex-col items-center justify-center pt-5 pb-6">
          <UploadIcon className="w-10 h-10 mb-3 text-slate-400" />
          <p className="mb-2 text-sm text-slate-400">
            <span className="font-semibold text-sky-400">Click to upload</span> or drag and drop
          </p>
          <p className="text-xs text-slate-500">PDF (MAX. 10MB)</p>
        </div>
        {currentFileName && (
          <p className="text-sm text-green-400 mt-1">Selected: {currentFileName}</p>
        )}
        <input
          id="pdf-upload"
          ref={fileInputRef}
          type="file"
          accept=".pdf"
          className="hidden"
          onChange={handleFileChange}
        />
      </label>
    </div>
  );
};

export default FileUpload;
