
import React from 'react';

const LoadingSpinner: React.FC = () => {
  return (
    <div className="flex items-center justify-center space-x-2">
      <div className="w-3 h-3 rounded-full animate-pulse bg-white"></div>
      <div className="w-3 h-3 rounded-full animate-pulse bg-white animation-delay-200"></div>
      <div className="w-3 h-3 rounded-full animate-pulse bg-white animation-delay-400"></div>
      <span className="ml-2 text-white">Processing...</span>
      <style>{`
        .animation-delay-200 {
          animation-delay: 0.2s;
        }
        .animation-delay-400 {
          animation-delay: 0.4s;
        }
      `}</style>
    </div>
  );
};

export default LoadingSpinner;
