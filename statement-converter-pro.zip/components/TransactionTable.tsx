
import React from 'react';
import { Transaction } from '../types';

interface TransactionTableProps {
  transactions: Transaction[];
}

const TransactionTable: React.FC<TransactionTableProps> = ({ transactions }) => {
  const formatCurrency = (value: number | string | undefined | null) => {
    if (value === null || value === undefined || value === '') return '';
    const num = Number(value);
    if (isNaN(num)) return String(value); // if it's not a number after all, show as is
    return num.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  return (
    <div className="overflow-x-auto bg-slate-700/50 shadow-md rounded-lg">
      <table className="w-full text-sm text-left text-slate-300">
        <thead className="text-xs text-sky-300 uppercase bg-slate-700">
          <tr>
            <th scope="col" className="px-4 py-3 sm:px-6">Date</th>
            <th scope="col" className="px-4 py-3 sm:px-6">Description</th>
            <th scope="col" className="px-4 py-3 sm:px-6 text-right">Debit</th>
            <th scope="col" className="px-4 py-3 sm:px-6 text-right">Credit</th>
            <th scope="col" className="px-4 py-3 sm:px-6 text-right hidden md:table-cell">Balance</th>
          </tr>
        </thead>
        <tbody>
          {transactions.map((tx, index) => (
            <tr key={index} className="border-b border-slate-600 hover:bg-slate-600/50 transition-colors duration-100">
              <td className="px-4 py-3 sm:px-6 whitespace-nowrap">{tx.date}</td>
              <td className="px-4 py-3 sm:px-6">{tx.description}</td>
              <td className="px-4 py-3 sm:px-6 text-right text-red-400">{formatCurrency(tx.debit)}</td>
              <td className="px-4 py-3 sm:px-6 text-right text-green-400">{formatCurrency(tx.credit)}</td>
              <td className="px-4 py-3 sm:px-6 text-right hidden md:table-cell">{formatCurrency(tx.balance)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TransactionTable;
