import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { Transaction } from '../types';

const API_KEY = process.env.API_KEY;

const getAiClient = () => {
  if (!API_KEY) {
    throw new Error("API_KEY is not configured. Please set process.env.API_KEY.");
  }
  return new GoogleGenAI({ apiKey: API_KEY });
};

const cleanTransactionValue = (value: any): number | null => {
  if (value === null || value === undefined || String(value).trim() === "") {
    return null;
  }
  const numStr = String(value).replace(/[^0-9.-]+/g, "");
  // Handle cases like "1,234.50-" which should be -1234.50
  if (numStr.endsWith('-') && numStr.startsWith('-')) { // e.g. --50 should be error or -50 if we are very lenient
    const num = parseFloat(numStr.substring(1, numStr.length -1));
    return isNaN(num) ? null : -num
  }
  if (numStr.endsWith('-')) {
    const num = parseFloat(numStr.substring(0, numStr.length -1));
    return isNaN(num) ? null : -num;
  }
  const num = parseFloat(numStr);
  return isNaN(num) ? null : num;
};

// Max characters for a single chunk of text sent to Gemini
const MAX_INPUT_TEXT_CHUNK_SIZE = 18000; // Reduced for safety margin with JSON output

// Helper to split text into manageable chunks by lines, respecting maxChunkSize
const splitTextIntoChunks = (text: string, maxChunkSize: number): string[] => {
  const chunks: string[] = [];
  let currentChunkLines: string[] = [];
  let currentChunkLength = 0;
  const lines = text.split('\n');

  for (const line of lines) {
    if (currentChunkLength + line.length + 1 > maxChunkSize && currentChunkLines.length > 0) {
      chunks.push(currentChunkLines.join('\n'));
      currentChunkLines = [];
      currentChunkLength = 0;
    }
    currentChunkLines.push(line);
    currentChunkLength += line.length + 1; // +1 for the newline character
  }

  if (currentChunkLines.length > 0) {
    chunks.push(currentChunkLines.join('\n'));
  }
  return chunks;
};

const fetchTransactionsFromGeminiChunk = async (
  ai: GoogleGenAI,
  textChunk: string,
  chunkIndex: number,
  totalChunks: number
): Promise<Transaction[]> => {
  const prompt = `
    You are an expert data extraction tool specializing in financial statements.
    Given THIS SEGMENT of text from a bank or credit card statement, extract all transaction details.
    This is segment ${chunkIndex + 1} of ${totalChunks}. Focus only on transactions clearly identifiable within this segment.
    Each transaction MUST include 'date', 'description'.
    It should also include 'debit' (for withdrawals, payments, or expenses) and 'credit' (for deposits, income, or refunds).
    If a 'balance' column is clearly identifiable per transaction, include 'balance'.
    - Dates should be parsed to 'YYYY-MM-DD' if possible. If not, use the format present in the text.
    - Descriptions should be captured as accurately as possible.
    - Debit and Credit values should be positive numbers. Do not include currency symbols. If a value is not present (e.g., no debit for a deposit), use null or omit the field for that transaction.
    - Balance, if present, should also be a number.

    Focus on tabular transaction data. Ignore summaries, headers, footers, or promotional text not part of the transaction list.
    Return the data as a JSON array of objects. Each object represents one transaction.
    Example of a transaction object:
    { "date": "2023-03-15", "description": "Online Purchase at AMAZON.COM", "debit": 55.99, "credit": null, "balance": 1234.56 }
    If no transactions are found in this segment, return an empty array: [].

    Statement Text Segment:
    ---
    ${textChunk}
    ---
    JSON Output:
  `;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-04-17",
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            temperature: 0.1,
        },
    });

    let jsonStr = response.text.trim();
    const fenceRegex = /^\s*```(?:json)?\s*\n?(.*?)\n?\s*```\s*$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[1]) {
      jsonStr = match[1].trim();
    }
    
    // If the response is an empty string, treat it as an empty array of transactions.
    if (jsonStr === "") {
        return [];
    }

    let parsedData: any;
    try {
      parsedData = JSON.parse(jsonStr);
    } catch (e) {
      console.error(`Failed to parse JSON response from Gemini for chunk ${chunkIndex + 1}:`, e);
      console.error(`Raw Gemini response text for chunk ${chunkIndex + 1}:`, response.text);
      // Return empty array for this chunk on parsing error to allow other chunks to proceed
      return []; 
    }

    if (!Array.isArray(parsedData)) {
        console.warn(`Gemini response for chunk ${chunkIndex + 1} was not an array:`, parsedData);
        if (parsedData && (parsedData.transactions || parsedData.data) && Array.isArray(parsedData.transactions || parsedData.data) ) {
            parsedData = parsedData.transactions || parsedData.data;
        } else {
           return []; // Not a valid transaction array structure
        }
    }
    
    return parsedData.map((item: any): Transaction => ({
      date: String(item.date || ''),
      description: String(item.description || 'N/A'),
      debit: cleanTransactionValue(item.debit),
      credit: cleanTransactionValue(item.credit),
      balance: cleanTransactionValue(item.balance),
    })).filter((tx: Transaction) => tx.date && tx.description !== 'N/A');

  } catch (error) {
    console.error(`Error calling Gemini API for chunk ${chunkIndex + 1}:`, error);
    // Allow other chunks to process by returning empty for this failed chunk
    return []; 
  }
};

export const extractTransactionsWithGemini = async (pdfText: string): Promise<Transaction[]> => {
  const ai = getAiClient();
  const textChunks = splitTextIntoChunks(pdfText, MAX_INPUT_TEXT_CHUNK_SIZE);
  let allTransactions: Transaction[] = [];

  if (textChunks.length === 0 && pdfText.trim().length > 0) {
    // This case should ideally not happen if pdfText is not empty,
    // but as a fallback, try to process the whole text if chunking yielded nothing.
    textChunks.push(pdfText);
  } else if (textChunks.length === 0 && pdfText.trim().length === 0) {
    return []; // No text to process
  }

  console.log(`Processing PDF text in ${textChunks.length} chunk(s).`);

  for (let i = 0; i < textChunks.length; i++) {
    console.log(`Fetching transactions from chunk ${i + 1} of ${textChunks.length}`);
    try {
      const chunkTransactions = await fetchTransactionsFromGeminiChunk(ai, textChunks[i], i, textChunks.length);
      allTransactions.push(...chunkTransactions);
    } catch (error) {
        console.error(`Error processing chunk ${i + 1}:`, error);
        // Continue to next chunk if one fails
    }
  }
  
  // De-duplicate transactions that might have been extracted at the boundaries of chunks
  const uniqueTransactions: Transaction[] = [];
  const seenTransactions = new Set<string>();

  for (const tx of allTransactions) {
    // Normalize amounts for consistent key generation
    const debitKey = tx.debit !== null && tx.debit !== undefined ? Number(tx.debit).toFixed(2) : 'null';
    const creditKey = tx.credit !== null && tx.credit !== undefined ? Number(tx.credit).toFixed(2) : 'null';
    // Balance is often less reliable for de-duplication, so an option to exclude or make it less strict.
    // For now, include it but be mindful.
    // const balanceKey = tx.balance !== null && tx.balance !== undefined ? Number(tx.balance).toFixed(2) : 'null';

    // Create a unique key for the transaction. Consider description might be slightly different if split.
    // Using first 50 chars of description might be more robust.
    const descriptionKey = tx.description.trim().substring(0, 50);
    const txKey = `${tx.date}|${descriptionKey}|d:${debitKey}|c:${creditKey}`;
    
    if (!seenTransactions.has(txKey)) {
        uniqueTransactions.push(tx);
        seenTransactions.add(txKey);
    }
  }
  
  if (pdfText.length > MAX_INPUT_TEXT_CHUNK_SIZE && allTransactions.length > 0 && uniqueTransactions.length === 0) {
      // This could happen if de-duplication was too aggressive or keys were not distinct enough
      // and all transactions from chunks were considered duplicates of each other.
      // In such an unlikely edge case, returning allTransactions before de-duplication might be a fallback.
      // For now, we trust the de-duplication.
      console.warn("De-duplication resulted in zero transactions from multiple chunks. Original count:", allTransactions.length);
  }


  if (uniqueTransactions.length === 0 && allTransactions.length > 0) {
    // If de-duplication somehow removed everything, but there were transactions.
    // This is an edge case, likely indicating an issue with the de-duplication key.
    // Fallback to returning all transactions from chunks to avoid losing data completely.
    console.warn("De-duplication resulted in an empty transaction list. Returning raw chunk transactions.");
    return allTransactions;
  }


  return uniqueTransactions;
};
