
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

// Retrieve API_KEY from environment variables.
// This follows the project guideline that process.env.API_KEY is pre-configured.
const API_KEY = process.env.API_KEY;

const getAiClientForOcr = () => {
  if (!API_KEY) {
    console.warn("API_KEY is not configured. OCR fallback will not be available.");
    return null;
  }
  try {
    return new GoogleGenAI({ apiKey: API_KEY });
  } catch (e) {
    console.error("Failed to initialize GoogleGenAI for OCR:", e);
    return null;
  }
};

// Heuristic: if pdf.js extracts less than this many characters per page on average,
// or total less than this for a single page PDF, consider it a candidate for OCR.
const MIN_TEXT_LENGTH_THRESHOLD_PER_PAGE = 100; 
const ABSOLUTE_MIN_TEXT_THRESHOLD = 200; // Overall minimum regardless of page count if > 1 page.

interface PdfPageImage {
  inlineData: {
    mimeType: 'image/png' | 'image/jpeg';
    data: string; // base64 encoded
  };
}

export const extractTextFromPdf = async (file: File): Promise<string> => {
  let pdfJsText = '';
  let numPages = 0;

  // 1. Try text extraction with pdf.js
  try {
    const arrayBuffer = await file.arrayBuffer();
    const typedArray = new Uint8Array(arrayBuffer);
    
    // Ensure pdfjsLib is available (loaded from CDN)
    if (typeof pdfjsLib === 'undefined' || !pdfjsLib.getDocument) {
        console.error("pdf.js library is not loaded correctly.");
        // Fallback to attempting OCR directly if pdf.js is broken
        return await ocrPdfWithGemini(file, ""); 
    }

    const pdf = await pdfjsLib.getDocument({ data: typedArray }).promise;
    numPages = pdf.numPages;

    for (let i = 1; i <= numPages; i++) {
      const page = await pdf.getPage(i);
      const textContent = await page.getTextContent();
      pdfJsText += textContent.items.map((item: any) => item.str).join(' ') + '\n';
    }
  } catch (error) {
    console.error('Error during pdf.js text extraction:', error);
    // Don't reject yet, try OCR fallback. pdfJsText will be empty or partial.
  }

  const threshold = numPages > 1 ? Math.max(ABSOLUTE_MIN_TEXT_THRESHOLD, numPages * MIN_TEXT_LENGTH_THRESHOLD_PER_PAGE) : MIN_TEXT_LENGTH_THRESHOLD_PER_PAGE;
  if (pdfJsText.trim().length >= threshold) {
    console.log("Sufficient text extracted by pdf.js.");
    return pdfJsText;
  }

  // 2. Fallback to OCR using Gemini if pdf.js text is insufficient
  console.log(`pdf.js extracted insufficient text (${pdfJsText.trim().length} chars, threshold ${threshold}). Attempting OCR fallback.`);
  return await ocrPdfWithGemini(file, pdfJsText);
};


async function ocrPdfWithGemini(file: File, initialText: string): Promise<string> {
  const ai = getAiClientForOcr();
  if (!ai) {
    // If AI client can't be initialized (e.g. no API key), and pdf.js failed,
    // return the (potentially empty) text from pdf.js.
    // App.tsx will show "Could not extract text..." if this is empty.
    return initialText;
  }

  try {
    const arrayBuffer = await file.arrayBuffer();
    const typedArray = new Uint8Array(arrayBuffer);

    if (typeof pdfjsLib === 'undefined' || !pdfjsLib.getDocument) {
        console.error("pdf.js library is not loaded correctly for OCR image generation.");
        return initialText; // Cannot proceed to render pages
    }
    const pdf = await pdfjsLib.getDocument({ data: typedArray }).promise;
    
    const imageParts: PdfPageImage[] = [];
    // Limit number of pages for OCR to prevent overly large requests.
    // Bank statements are usually not excessively long. Max 10 pages for OCR.
    const pagesToOcr = Math.min(pdf.numPages, 10); 

    for (let i = 1; i <= pagesToOcr; i++) {
      const page = await pdf.getPage(i);
      // Increased scale for better OCR quality, up to a reasonable limit.
      // Higher scale = larger image data.
      const viewport = page.getViewport({ scale: 2.0 }); 

      const canvas = document.createElement('canvas');
      const context = canvas.getContext('2d');
      if (!context) {
        console.error('Failed to get canvas context for page', i);
        continue;
      }
      canvas.height = viewport.height;
      canvas.width = viewport.width;

      await page.render({ canvasContext: context, viewport: viewport }).promise;
      
      // Using JPEG for potentially smaller image sizes than PNG for photos/scans.
      // Quality can be adjusted. 0.9 is high quality.
      const imageDataUrl = canvas.toDataURL('image/jpeg', 0.9); 
      const base64EncodedString = imageDataUrl.split(',')[1];

      if (base64EncodedString) {
        imageParts.push({
          inlineData: {
            mimeType: 'image/jpeg',
            data: base64EncodedString,
          },
        });
      }
    }

    if (imageParts.length === 0) {
      console.warn("No images could be generated from PDF for OCR.");
      return initialText; // Return initial text if no images were made
    }
    
    const ocrPrompt = `You are an OCR (Optical Character Recognition) engine. Extract all text from the following page image(s) of a document. 
    Preserve the original layout and structure of the text as much as possible, including line breaks and spacing. 
    Combine text from all images into a single continuous text block. If there are multiple pages, clearly delineate or simply concatenate the text from each subsequent page.
    Focus solely on extracting the text as it appears. Do not summarize, interpret, or add any commentary.`;

    const textPart = { text: ocrPrompt };
    
    const response: GenerateContentResponse = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-04-17", 
        contents: { parts: [...imageParts, textPart] },
    });

    const ocrText = response.text;

    if (!ocrText || !ocrText.trim()) {
        console.warn("OCR with Gemini returned empty or minimal text.");
        return initialText; // Return initial text if OCR failed
    }
    
    console.log("Text successfully extracted via Gemini OCR fallback.");
    return ocrText;

  } catch (ocrError) {
    console.error('Error during OCR fallback with Gemini:', ocrError);
    return initialText;
  }
}
