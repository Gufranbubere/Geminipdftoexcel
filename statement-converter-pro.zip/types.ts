
export interface Transaction {
  date: string;
  description: string;
  debit?: number | string | null; // Allow string temporarily for parsing flexibility
  credit?: number | string | null; // Allow string temporarily for parsing flexibility
  balance?: number | string | null; // Allow string temporarily for parsing flexibility
}

// For pdf.js and papaparse loaded via CDN
declare global {
  const pdfjsLib: any;
  const Papa: any;
}
