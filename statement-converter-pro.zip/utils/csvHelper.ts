
import { Transaction } from '../types';

export const downloadCsv = (data: Transaction[], filename: string = 'transactions.csv'): void => {
  if (!data || data.length === 0) {
    console.error('No data to download.');
    return;
  }

  // Ensure Papa is loaded (it's included via CDN in index.html)
  if (typeof Papa === 'undefined') {
    console.error('PapaParse library is not loaded.');
    alert('Error: CSV export library not loaded. Please refresh the page.');
    return;
  }

  const csv = Papa.unparse(data, {
    header: true,
    // Define columns explicitly to ensure order and handle optional fields
    columns: ["date", "description", "debit", "credit", "balance"] 
  });

  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};
